#!/bin/bash

{
sudo setenforce 0
sed -i 's/SELINUX=\S.*/SELINUX=disabled/g' /etc/selinux/config
sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/g' /etc/ssh/sshd_config
swapoff -a
sed -i -r 's/(.+ swap .+)/#\1/' /etc/fstab
rm -f /swapfile

yum -y -q upgrade
package-cleanup -q -y --oldkernels --count=1
yum remove -y -q open-vm-tools

cat <<EOF > /etc/modules-load.d/99-k8s-modules.conf
br_netfilter
overlay
EOF
modprobe br_netfilter
modprobe overlay

cat <<EOF > /etc/sysctl.d/99-k8s-sysctl.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
net.ipv4.ip_forward = 1
EOF
sysctl -q --system

timedatectl set-timezone America/Sao_Paulo
sed -i '1 s/^/server gps.ntp.br iburst\n/' /etc/chrony.conf
sed -i '1 s/^/server c.st1.ntp.br iburst\nserver d.st1.ntp.br iburst\n/' /etc/chrony.conf
sed -i '1 s/^/server a.st1.ntp.br iburst\nserver b.st1.ntp.br iburst\n/' /etc/chrony.conf
systemctl -q restart chronyd

systemctl enable --now firewalld
systemctl start firewalld
firewall-cmd -q --set-default-zone=trusted
firewall-cmd -q --permanent --zone=trusted --add-service=dhcp
firewall-cmd -q --permanent --zone=trusted --add-service=dhcpv6-client
firewall-cmd -q --permanent --zone=trusted --add-service=dns
firewall-cmd -q --permanent --zone=trusted --add-service=etcd-client
firewall-cmd -q --permanent --zone=trusted --add-service=etcd-server
firewall-cmd -q --permanent --zone=trusted --add-service=git
firewall-cmd -q --permanent --zone=trusted --add-service=http
firewall-cmd -q --permanent --zone=trusted --add-service=https
firewall-cmd -q --permanent --zone=trusted --add-service=samba-client
firewall-cmd -q --permanent --zone=trusted --add-service=ssh
firewall-cmd -q --permanent --zone=trusted --add-service=snmp
firewall-cmd -q --permanent --zone=trusted --add-service=ntp
firewall-cmd -q --permanent --zone=trusted --add-port=2379-2380/tcp
firewall-cmd -q --permanent --zone=trusted --add-port=8285/udp
firewall-cmd -q --permanent --zone=trusted --add-port=6443/tcp
firewall-cmd -q --permanent --zone=trusted --add-port=6783/tcp
firewall-cmd -q --permanent --zone=trusted --add-port=6783/udp
firewall-cmd -q --permanent --zone=trusted --add-port=6784/udp
firewall-cmd -q --permanent --zone=trusted --add-port=8090/tcp
firewall-cmd -q --permanent --zone=trusted --add-port=8091/tcp 
firewall-cmd -q --permanent --zone=trusted --add-port=8472/udp
firewall-cmd -q --permanent --zone=trusted --add-port=10250/tcp
firewall-cmd -q --permanent --zone=trusted --add-port=10251/tcp
firewall-cmd -q --permanent --zone=trusted --add-port=10252/tcp
firewall-cmd -q --permanent --zone=trusted --add-port=10255/tcp
firewall-cmd -q --permanent --zone=trusted --add-port=30000-32767/tcp
firewall-cmd -q --reload

yum install -y -q epel-release  
yum install -y -q https://packages.endpointdev.com/rhel/7/os/x86_64/endpoint-repo.x86_64.rpm 
yum-config-manager -q -y --enable centosplus >/dev/null 2>&1
yum-config-manager -q -y --add-repo https://download.docker.com/linux/centos/docker-ce.repo 

cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://packages.cloud.google.com/yum/repos/kubernetes-el7-x86_64
enabled=1
gpgcheck=1
gpgkey=https://packages.cloud.google.com/yum/doc/rpm-package-key.gpg
exclude=kubelet kubeadm kubectl
EOF

sudo yum groups install -y "Minimal Install"
yum install -y -q autoconf kernel-devel kernel-headers dkms gcc patch libX11 libXt libXext libXmu wget glibc-headers glibc-devel nc nmap telnet traceroute net-tools bind-utils htop lvm2 device-mapper-persistent-data samba-client jq golang perl arptables ipvsadm containerd.io kubelet kubeadm kubectl --disableexcludes=kubernetes

yum clean all

systemctl -q start containerd
systemctl -q enable --now containerd
systemctl -q start kubelet
systemctl -q enable --now kubelet


rm -f /etc/containerd/config.toml
containerd config default > /etc/containerd/config.toml
sed -i 's/SystemdCgroup = false/SystemdCgroup = true/' /etc/containerd/config.toml

systemctl -q stop containerd
systemctl -q stop kubelet

wget -nv "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl-convert" -P /tmp >/dev/null 2>&1
install -o root -g root -m 0755 /tmp/kubectl-convert /usr/local/bin/kubectl-convert
rm -f /tmp/kubectl-convert

kubectl completion bash > /etc/bash_completion.d/kubectl.bash
kubeadm completion bash > /etc/bash_completion.d/kubeadm.bash
}
exit $?
