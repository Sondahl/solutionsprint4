#!/bin/bash

{
wget -nv http://download.virtualbox.org/virtualbox/7.0.6/VBoxGuestAdditions_7.0.6.iso -P /tmp >/dev/null 2>&1
mount -o loop,ro /tmp/VBoxGuestAdditions_7.0.6.iso /media
sh /media/VBoxLinuxAdditions.run 
umount /media
rm -f /tmp/VBoxGuestAdditions_7.0.6.iso

mkdir -p /etc/vbox/
cat <<EOF | tee /etc/vbox/networks.conf
* 0.0.0.0/0 ::/0
EOF
cat <<EOF | tee /etc/modules-load.d/00-vbox-modules.conf
vboxguest
vboxsf
vboxvideo
EOF

echo "$(sudo ssh-keygen -y -f /tmp/insecure_private_key) vagrant" > /home/vagrant/.ssh/authorized_keys
sudo ssh-keygen -y -f /tmp/insecure_private_key
sudo rm -f /etc/ssh/*key*
sudo shutdown -h now
}
exit $?

